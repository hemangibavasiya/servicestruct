
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'hbavasiya',
  applicationName: 'tempservice',
  appUid: 'JH3m8PttTJtskZFcYw',
  orgUid: 'eb1663b4-aae9-4570-9e46-c12553b3c604',
  deploymentUid: 'c5eca8e6-da82-4954-beb7-712a8a06e341',
  serviceName: 'tempservice',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'tempservice-dev-demogetapi', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.demogetapi, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}